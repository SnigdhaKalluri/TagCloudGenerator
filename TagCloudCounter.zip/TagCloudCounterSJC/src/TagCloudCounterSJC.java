import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

/**
 * A Java program that sorts out only the words in a given input file, finds the
 * number of times they occur, and outputs an HTML document with a table of the
 * words and counts listed in alphabetical order.
 *
 *
 * @author Snigdha Kalluri
 *
 *
 */
public final class TagCloudCounterSJC {

    /**
     * Default constructor--private to prevent instantiation.
     */
    private TagCloudCounterSJC() {
        // no code needed here
    }

    /**
     *
     * Sorts the List {@code List<Entry<String,Integer>>} numerically then makes
     * a hashMap {@code hashMap<String,String>} of the desired number of words
     * taking the Entries from the List with the highest number of values.The
     * hashMap{@code hashMap<String,String>} is then sorted alphabetically.
     *
     * @param terms
     *            given List{@code List<Entry<String,String>} that contains the
     *            words in the file along with a value of how many times the
     *            word occurs.
     * @requires <pre> terms.size()>0 </pre>
     * @returns HashMap<String,String>terms
     */
    public static HashMap<String, String> generateSizeOfFont(
            List<Entry<String, Integer>> terms) {
        HashMap<String, String> fontSize = new HashMap<String, String>();
        int minVal = 0;
        int maxVal = 0;
        for (Entry<String, Integer> temp : terms) {
            if (temp.getValue() > maxVal) {
                maxVal = temp.getValue();
            }
            if (temp.getValue() < minVal || minVal == 0) {
                minVal = temp.getValue();
            }
        }
        int fontMax = 48;
        int fontMin = 11;
        int font;
        for (Entry<String, Integer> t : terms) {
            if (minVal == maxVal) {
                font = fontMin;
            } else {
                font = ((fontMax - fontMin) * (t.getValue() - minVal))
                        / (maxVal - minVal) + fontMin;
            }
            //add "f" for the font syntax in HTML.
            String fontFin = "f" + font;
            fontSize.put(t.getKey(), fontFin);
        }
        return fontSize;
    }

    /**
     * Returns the first "word" (maximal length string of characters not in
     * {@code separators}) or "separator string" (maximal length string of
     * characters in {@code separators}) in the given {@code text} starting at
     * the given {@code position}.
     *
     * @param text
     *            the {@code String} from which to get the word or separator
     *            string
     * @param position
     *            the starting index
     * @param separators
     *            the {@code String} of separator characters
     * @return the first word or separator string found in {@code text} starting
     *         at index {@code position}
     * @requires 0 <= position < |text|
     * @ensures <pre>
     * nextWordOrSeparator =
     *   text[position, position + |nextWordOrSeparator|)  and
     * if entries(text[position, position + 1)) intersection separators = {}
     * then
     *   entries(nextWordOrSeparator) intersection separators = {}  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      intersection separators /= {})
     * else
     *   entries(nextWordOrSeparator) is subset of separators  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      is not subset of separators)
     * </pre>
     */
    private static String nextWordOrSeparator(String text, int position,
            String separators) {
        StringBuilder buildWord = new StringBuilder();
        int pos = position;
        boolean isSeparator = separators.indexOf(text.charAt(pos)) == -1;
        while (pos < text.length() && isSeparator == (separators
                .indexOf(text.charAt(pos)) == -1)) {
            buildWord.append(text.charAt(pos));
            pos++;
        }
        return buildWord.toString();
    }

    /**
     *
     * Generates a List {@code List<Entry<String,Integer>>} of terms based on
     * the number of desired inputs by the client and takes the Entrys in
     * HashMap{@code HashMap<String,Integer>} that have the highest integer
     * value. This is done by sorting the HashMap and then removing the desired
     * amount of Entries and adding the entries to a
     * List{@code List<Entry<<String,String>>}. The list is them sorted
     * alphabetically.
     *
     ** @param terms
     *            the HashMap{@code HashMap<String,Integer>} that contains the
     *            keys of every word in the input file along with values of how
     *            many times the word occurs in the file.
     * @param number
     *            the desired number of words the client wants
     *
     * @returns List<Entry<String,Integer>>, this list contains the desired
     *          number of entries of strings of words that have the highest
     *          value or occurances in the HashMap and when returned is sorted
     *          alphabetically.
     *
     * @requires <pre> terms.size()>0 and number>0 </pre>
     * @ensures List<Entry<<String,String>>.size()=number and the List contains
     *          the Entries in terms with the highest values and the List is
     *          sorted alphabetically.
     *
     */
    public static List<Entry<String, Integer>> sortMap(
            HashMap<String, Integer> terms, Integer number) {

        Comparator<Entry<String, Integer>> sortNum = new IntegerOrder();
        Comparator<Entry<String, Integer>> sortAlph = new AlphabeticalOrder();

        List<Entry<String, Integer>> sortedList = new LinkedList<Entry<String, Integer>>();
        Set<Entry<String, Integer>> addToList = new HashSet<Entry<String, Integer>>();
        addToList = terms.entrySet();
        //add all the entries in addToList (all the terms in terms) to sortedList
        for (Entry<String, Integer> pairs : addToList) {
            sortedList.add(pairs);
        }
        //sort sortedList numerically by its values.
        Collections.sort(sortedList, sortNum);
        List<Entry<String, Integer>> finalSortedList = new LinkedList<Entry<String, Integer>>();
        //add the desired number of entries in sortedList to finalSortedList
        //sortedList is sorted numerically by its values so the number of entries added to finalSorted list are the entries with the highest values.
        for (int i = 0; i < number; i++) {
            Entry<String, Integer> pairs = sortedList.get(i);
            finalSortedList.add(pairs);
        }
        //sort finalSortedList alphabetically.
        Collections.sort(finalSortedList, sortAlph);

        return finalSortedList;
    }

    /**
     *
     * Generates the HashMap{@code HashMap<String,Integer>} of a key of words in
     * the input file and a value of how many times that word occurs in the
     * file. Keys are determines if they are words by using nextWordOrSeparator.
     *
     * @param fileName
     *            string linked to the input file
     * @param separators
     *            the {@code String} of separator characters
     *
     * @param input
     *            the {@code BufferedReader} reader of the input file.
     *
     * @returns HashMap<Strings,Integer>, this HashMap contains keys of the
     *          strings of terms that are found in the input file and values of
     *          number of times the word occurs in the file.
     *
     * @requires <pre> fileName.length()>0 and Seporator.length()>0</pre>
     *
     * @ensures HashMap<String,String> doesn't contain any separators from the
     *          separatorSetcand the values of Integers correctly correlate to
     *          how many times the word occurs in the file.
     *
     */
    public static HashMap<String, Integer> fileToMap(String fileName,
            String separators, BufferedReader input) {
        HashMap<String, Integer> terms = new HashMap<>();
        String newElement = "";
        //reads through file until it has reached the end
        try {
            newElement = input.readLine();
        } catch (IOException e) {
            System.err.println("Error: cannot read line");
        }
        while (newElement != null) {
            int i = 0;
            // reads through all the characters in the newElement to check for separators
            //added the second null check because of eclipse bug.
            while (newElement != null && i < newElement.length()) {
                //get individual words from the nextLine (newElement)
                String nextWord = nextWordOrSeparator(newElement, i,
                        separators);

                if (separators.indexOf(nextWord.charAt(0)) < 0) {
                    // as long as the next word is not empty and it doesn't
                    //contain a separator, the word is converted to all
                    String noUpperCase = nextWord.toLowerCase();
                    if (!terms.containsKey(noUpperCase)) {
                        terms.put(noUpperCase, 1);
                    } else {
                        int newCount = terms.get(noUpperCase) + 1;
                        terms.replace(noUpperCase, newCount);
                    }

                }
                i = i + nextWord.length();
            }
            try {
                newElement = input.readLine();
            } catch (IOException e) {
                System.err.println("Error: cannot read line");
            }
        }
        return terms;
    }

    //create comparator to use later in order to organize terms alphabetically
    private static class AlphabeticalOrder
            implements Comparator<Entry<String, Integer>> {
        /**
         * Returns a negative integer, zero, or a positive integer as the first
         * Entry's key is less than, equal to, or greater than the second
         * Entry's key.
         *
         * @param wordOne
         *            the first Entry{@code Entry<String,Integer>}
         * @param wordTwo
         *            the entry Entry{@code Entry<String,Integer>}
         *
         * @requires <pre> wordOne.key().length()>0 and wordTwo.key().length()>0 </pre>
         *
         * @ensures int returned
         *          =wordOne.key().compareToIgnoreCase(wordTwo.key()) {the
         *          Integer returned shows the correct lexigraphic relationship
         *          between the two words of the keys}
         *
         * @returns integer that is either, -1, 1, or 0 depending on the
         *          relationship of the two words of the keys of the Entries
         */
        @Override
        public int compare(Entry<String, Integer> wordOne,
                Entry<String, Integer> wordTwo) {

            int result = wordOne.getKey().compareToIgnoreCase(wordTwo.getKey());
            if (result == 0) {
                result = Integer.compare(wordTwo.getValue(),
                        wordOne.getValue());
            }
            return result;
        }

    }

    //create comparator to use later in order to organize terms numerically
    private static class IntegerOrder
            implements Comparator<Entry<String, Integer>> {
        /**
         * Returns a negative integer, zero, or a positive integer as the first
         * Entries value is less than, equal to, or greater than the second
         * Entries value.
         *
         * @param intOne
         *            the first Entry{@code Entry<String,Integer>}
         * @param intTwo
         *            the second Entry{@code Entry<String,Integer>}
         *
         * @requires <pre> intOne>0 and intTwo>0 </pre>
         *
         * @ensures int returned =Integer.compare(intTwo.getValue(),
         *          intOne.getValue()) {the integer returned shows the correct
         *          numeric relationship between the two numbers}
         *
         * @returns integer that is either, -1, 1, or 0 depending on the
         *          relationship of the two entry values.
         */
        @Override
        public int compare(Entry<String, Integer> intOne,
                Entry<String, Integer> intTwo) {

            int result = Integer.compare(intTwo.getValue(), intOne.getValue());
            if (result == 0) {
                result = intOne.getKey().compareToIgnoreCase(intTwo.getKey());
            }
            return result;
        }
    }

    /**
     * Prints the title page for the main HTML page. This page contains the
     * number of desired words requested by the user and prints each word in a
     * font that corresponds to the number of times the word occured in the
     * input file.
     *
     * @param HTML
     *            The PrintWriter {@code PrintWriter} that contains where to
     *            generate the html files.
     *
     ** @param filename
     *            string linked to the input file
     *
     * @param font
     *            given HashMap{@code HashMap<String,String>} that contain keys
     *            of the words with the highest values in the file and values of
     *            their calculated font size.
     *
     * @param number
     *            {@code Integer} the desired number of words in the file
     *
     * @param sortedTerms
     *            {@code List<Entry<String,Integer>>} that contains the word
     *            (the key) and the number of times the word occurs (the value)
     *            in the file.
     *
     * @requires <pre> sortedTerms.size()>0 and font.size()==sortedTerms.size() and number>0 and filename.length()>0 </pre>
     *
     * @ensures {html pages printed containing <title> Top " + number + " words
     *          in " + filename</title>,
     *          <h2>"Top " + number + " words in " + filename</h2>,
     *          <h3>Index</h3> } for each word <span style=\"cursor:default\" "
     *          + strClass + "=\"" + fontNum + "\"" + " title=\"count: " +
     *          pair.getValue() + "\">" + pair.getKey() + "</span>
     */
    public static void generateHTML(PrintWriter HTML, String filename,
            HashMap<String, String> font, Integer number,
            List<Entry<String, Integer>> sortedTerms) {
        String strClass = "class";
        HTML.println("<html>");
        HTML.println("<head>");
        HTML.println(
                "<title>Top " + number + " words in " + filename + "</title>");

        HTML.println(
                "<link href=\"http://web.cse.ohio-state.edu/software/2231/web-sw2/assignments/projects/tag-cloud-generator/data/tagcloud.css\" rel=\"stylesheet\" type=\"text/css\">");
        HTML.println("</head>");
        HTML.println("<body>");
        HTML.println(
                "<h2> " + "Top " + number + " words in " + filename + "</h2>");
        HTML.println("<hr>");
        HTML.println("<div " + strClass + "=\"cdiv\">");
        HTML.println("<p " + strClass + "=\"cbox\">");
        //runs through the terms queue and prints the words as well as their counts
        //it to the HTML page in a table
        int count = 0;
        while (count < number) {
            //get pair value
            Entry<String, Integer> pair = sortedTerms.remove(0);
            //to assign to the string fontNum
            String fontNum = font.get(pair.getKey());
            HTML.println("<span style=\"cursor:default\" " + strClass + "=\""
                    + fontNum + "\"" + " title=\"count: " + pair.getValue()
                    + "\">" + pair.getKey() + "</span>");
            count++;
        }
        HTML.println("</p>");
        HTML.println("</div>");
        HTML.println(" </body>");
        HTML.println("</html>");
    }

    /**
     * Checks whether the given {@code String} represents a valid integer value
     * in the range Integer.MIN_VALUE..Integer.MAX_VALUE.
     *
     * @param s
     *            the {@code String} to be checked
     * @return true if the given {@code String} represents a valid integer,
     *         false otherwise
     * @ensures canParseInt = [the given String represents a valid integer]
     */
    private static boolean canParseInt(String s) {
        //This is copied from the cse components.
        assert s != null : "Violation of: s is not null";
        boolean var = false;
        try {
            Integer.parseInt(s);
            var = true;
        } catch (NumberFormatException e) {
            var = false;
        }
        return var;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments; unused here
     */
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter the name of the input file: ");
        String inputFilename = in.nextLine();
        BufferedReader inputFile;
        try {
            inputFile = new BufferedReader(new FileReader(inputFilename));
        } catch (IOException e) {
            System.err.println("Error: cannot open input file");
            in.close();
            return;
        }
        System.out.print("Enter the name of the output file: ");
        String outputFilename = in.nextLine();
        boolean outputError = false;
        PrintWriter outputFile = null;
        try {
            outputFile = new PrintWriter(
                    new BufferedWriter(new FileWriter(outputFilename)));
        } catch (IOException e) {
            System.err.println("Error: cannot create output file");
            outputError = true;
        }
        String num = "";
        do {
            System.out.println(
                    "Enter a positive integer of words to be included in the tag cloud generator: ");
            num = in.nextLine();
        } while (!canParseInt(num) || Integer.parseInt(num) <= 0);
        int number = Integer.parseInt(num);
        if (!outputError) {
            //canParseInt then check if it is greater than zero
            String separator = " \t\n\r,-.!?[]';:/()*_\"";
            HashMap<String, Integer> mapOG = fileToMap(inputFilename, separator,
                    inputFile);
            if (mapOG.size() < number) {
                number = mapOG.size();
            }
            List<Entry<String, Integer>> mapSort = sortMap(mapOG, number);
            HashMap<String, String> mapFont = generateSizeOfFont(mapSort);
            generateHTML(outputFile, inputFilename, mapFont, number, mapSort);
            outputFile.close();
        }
        in.close();
        try {
            inputFile.close();
        } catch (IOException e) {
            System.err.println("Error: cannot close input file");
        }
    }

}
